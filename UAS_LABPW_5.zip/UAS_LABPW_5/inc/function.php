<?php
    function rupiah ($angka){
        $harga = "Rp " . number_format($angka,0,',','.');
        return $harga;
    }

    function kilometer ($km){
        $kilometer = number_format($km,0,'','.');
        return $kilometer;
    }
?>