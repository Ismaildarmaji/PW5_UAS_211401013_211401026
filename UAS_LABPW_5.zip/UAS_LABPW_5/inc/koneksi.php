<?php
$server_name="localhost";
$username="root";
$password="";
$db_name="showroom";

$koneksi= mysqli_connect($server_name,$username,$password,$db_name);

if (!$koneksi) {
    die("Koneksi Gagal: " . mysqli_connect_error());
    }
?>

<!-- end -->