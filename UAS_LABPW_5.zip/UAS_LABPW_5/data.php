<!DOCTYPE html>
<html lang="en">

<head>
    <title>Data</title>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.min.js" integrity="sha384-+sLIOodYLS7CIrQpBjl+C7nPvqq+FbNUBDunl/OZv93DB7Ln/533i8e/mZXLi/P+" crossorigin="anonymous"></script>

    <style type="text/css">
        * {
    box-sizing: border-box;
  }
  
  .container{
    width: 750px;

  }
  .card{
    margin: 50px;
    padding: 50px;
  }

  .btn-danger{
    background: #555;
  }
  .card-title{
    text-align: center;
  }

  body {
    font-family: Arial;

    
    background: #fff;
  }
  
  footer {
    background: #ccc;
    color: #555;
    padding: 20px;
    text-align: center;
  }
  
    </style>
</head>

<body>
  <!-- Navbar -->
    <nav class="navbar sticky-top navbar-expand-lg navbar-dark bg-dark">
        <a class="navbar-brand" href="#">
          <img src="dist/img/logo1.png" width="55" height="55" alt="">
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo03" aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <a class="navbar-brand" href="#">ISMARU SHOWROOM</a>
      
        <div class="collapse navbar-collapse" id="navbarTogglerDemo03">
          <ul class="navbar-nav ml-auto mt-2 mt-lg-0">
            <li class="nav-item active">
              <a class="nav-link" href="data.php">Home <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
              <a class="nav-link "href="login.php">login Admin</a>
            </li>
          </ul>
          <form class="form-inline my-2 my-lg-0">
            <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
            <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
          </form>
        </div>
      </nav>
    
    <!-- carousel -->
    <div class="container">
      <div id="carouselExampleCaptions" class="carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">
          <li data-target="#carouselExampleCaptions" data-slide-to="0" class="active"></li>
          <li data-target="#carouselExampleCaptions" data-slide-to="1"></li>
          <li data-target="#carouselExampleCaptions" data-slide-to="2"></li>
        </ol>
        <div class="carousel-inner">
          <div class="carousel-item active">
            <img src="image/fortuner.png" class="d-block w-100" alt="..." >
            
          </div>
          <div class="carousel-item">
            <img src="image/pajero.png" class="d-block w-100" alt="...">
            
          </div>
          <div class="carousel-item">
            <img src="image/landcruiser.png" class="d-block w-100" alt="...">
            
          </div>
        </div>
        <button class="carousel-control-prev" type="button" data-target="#carouselExampleCaptions" data-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="sr-only">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-target="#carouselExampleCaptions" data-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="sr-only">Next</span>
        </button>
      </div>
    </div>
 <br>
 <!--Banner-->
    <div class="container-fluid banner">
      <div class="container text-center">
        <h2 class="display-4">Welcome</h2>
        <p>Here you can acces the official website</p>
        <a href="https://www.carsome.id/?utm_source=Google&utm_medium=Search&utm_campaign=ID_DSA_C2B_&utm_term=Search_DSA_C2B_ID_Perf_Conv_&utm_content&gclid=Cj0KCQiAwJWdBhCYARIsAJc4idCOE5E4lpGv6zq-Q57v14DGWdybxKhuJ-ffjp0Wft6rDWHP_A2GrYkaAt0jEALw_wcB">
          <button type="button" class="btn btn-danger ">EXPLORE NOW</button>
        </a>     
      </div>
    </div>

    <!--card-->
    <div class="card-deck">
      <div class="card">
        <img src="foto/fortuner.png" class="card-img-top" alt="...">
        <div class="card-body">
          <h5 class="card-title">FORTUNER</h5>
          <p class="card-text">SUV terbaru dari Toyota, Fortuner, hadir dengan 6 varian. Varian tertinggi hadir dengan mesin Diesel 2755 cc, yang mampu menghasilkan tenaga hingga 200 hp dan torsi puncak 499 Nm. Fortuner 4x4 2.8 GR Sport AT DSL berkapasitas 7-penupang dibekali juga dengan transmisi 6-Speed Automatic. Sistem keamanannya dibekali Central Locking & Power Door Locks.</p>
        </div>
      </div>
      <div class="card">
        <img src="image/pajero.png" class="card-img-top" alt="...">
        <div class="card-body">
          <h5 class="card-title">PAJERO SPORT</h5>
          <p class="card-text">SUV yang tersedia dalam daftar harga Rp 537,6 - 720,5 Juta di Indonesia. Ini tersedia dalam 5 warna, 6 varian, 2 pilihan mesin, dan 2 opsi transmisi: Manual dan Otomatis di Indonesia. Mobil ini memiliki ground clearance 218 mm dengan dimensi sebagai berikut: 4825 mm L x 1815 mm W x 1835 mm H. Lebih dari 83 pengguna telah memberikan penilaian untuk Pajero Sport berdasarkan fitur, jarak tempuh, kenyamanan tempat duduk dan kinerja mesin. Cicilan bulanan terendah dimulai dari Rp 36,53 Million (selama 12 bulan). Pesaing terdekat Mitsubishi Pajero Sport adalah Fortuner, Kijang Innova, CRV dan Koleos.</p>
          
        </div>
      </div>
      <div class="card">
        <img src="image/landcruiser.png" class="card-img-top" alt="...">
        <div class="card-body">
          <h5 class="card-title">LANDCRUISER</h5>
          <p class="card-text">SUV yang tersedia dalam daftar harga Rp 2,42 - 2,47 Milyar di Indonesia. Ini tersedia dalam 4 warna, 2 varian, 1 pilihan mesin, dan 1 opsi transmisi: Otomatis di Indonesia. Mobil ini memiliki ground clearance 235 mm dengan dimensi sebagai berikut: 4965 mm L x 1990 mm W x 1945 mm H. Lebih dari 7 pengguna telah memberikan penilaian untuk Land Cruiser berdasarkan fitur, jarak tempuh, kenyamanan tempat duduk dan kinerja mesin. Cicilan bulanan terendah dimulai dari Rp 480,38 Million (selama 60 bulan). Pesaing terdekat Toyota Land Cruiser adalah Macan, Range Rover Evoque, Discovery dan Range Rover Velar.</p>
          
        </div>
      </div>
    </div>

<br>
    <div class="card-deck">
      <div class="card">
        <img src="foto/crv.png" class="card-img-top" alt="...">
        <div class="card-body">
          <h5 class="card-title">CRV</h5>
          <p class="card-text">Crossover yang tersedia dalam daftar harga Rp 515,9 - 668,4 Juta di Indonesia. Ini tersedia dalam 4 warna, 4 varian, 2 pilihan mesin, dan 1 opsi transmisi: CVT di Indonesia. Dimensi CRV adalah 4623 mm L x 1855 mm W x 1657 mm H. Lebih dari 65 pengguna telah memberikan penilaian untuk CRV berdasarkan fitur, jarak tempuh, kenyamanan tempat duduk dan kinerja mesin. Cicilan bulanan terendah dimulai dari Rp 40 Million (selama 60 bulan). Pesaing terdekat Honda CRV adalah HRV, Kijang Innova, Pajero Sport dan Fortuner.</p>
          
        </div>
      </div>
      <div class="card">
        <img src="foto/pngwing.com (2).png" class="card-img-top" alt="...">
        <div class="card-body">
          <h5 class="card-title">JAZZ</h5>
          <p class="card-text">Jazz tersedia dalam pilihan mesin Bensin di Indonesia Hatchback baru dari Honda hadir dalam 8 varian. Bicara soal spesifikasi mesin Honda Jazz, ini ditenagai dua pilihan mesin Bensin berkapasitas 1497 cc. Jazz tersedia dengan transmisi Manual and CVT tergantung variannya. Jazz adalah Hatchback 5 seater dengan panjang 4035 mm, lebar 1694 mm, wheelbase 2530 mm.</p>
          
        </div>
      </div>
      <div class="card">
        <img src="foto/pngwing.com (1).png" class="card-img-top" alt="...">
        <div class="card-body">
          <h5 class="card-title">CAMRY</h5>
          <p class="card-text"> Sedan yang tersedia dengan harga Rp 741,7 Juta di Indonesia. Ini tersedia dalam 7 warna, 1 varian, 1 pilihan mesin, dan 1 opsi transmisi: Otomatis di Indonesia. Dimensi Camry adalah 4885 mm L x 1840 mm W x 1445 mm H. Lebih dari 10 pengguna telah memberikan penilaian untuk Camry berdasarkan fitur, jarak tempuh, kenyamanan tempat duduk dan kinerja mesin. Cicilan bulanan terendah dimulai dari Rp 106,48 Million (selama 60 bulan). Pesaing terdekat Toyota Camry adalah Camry Hybrid, 6 , Accord dan A-Class Sedan.</p>
          
        </div>
      </div>
    </div>

    <footer>
        Copyright &copy; 2022 ISMARU SHOWROOM
    </footer>
</body>

</html>