<?php

    if(isset($_GET['kode'])){
        $sql_cek = "SELECT * FROM tb_mobil WHERE no_seri='".$_GET['kode']."'";
        $query_cek = mysqli_query($koneksi, $sql_cek);
        $data_cek = mysqli_fetch_array($query_cek,MYSQLI_BOTH);
    }
?>

<div class="card card-success">
	<div class="card-header">
		<h3 class="card-title">
			<i class="fa fa-edit"></i> Ubah Data</h3>
	</div>
	<form action="" method="post" enctype="multipart/form-data">
		<div class="card-body">

			<div class="form-group row">
				<label class="col-sm-2 col-form-label">No Seri</label>
				<div class="col-sm-5">
					<input type="text" class="form-control" id="no_seri" name="no_seri" value="<?php echo $data_cek['no_seri']; ?>"
					 readonly/>
				</div>
			</div>

			<div class="form-group row">
				<label class="col-sm-2 col-form-label">Nama</label>
				<div class="col-sm-5">
					<input type="text" class="form-control" id="nama" name="nama" value="<?php echo $data_cek['nama']; ?>"
					/>
				</div>
			</div>

			<div class="form-group row">
				<label class="col-sm-2 col-form-label">Transmisi</label>
				<div class="col-sm-5">
					<input type="text" class="form-control" id="transmisi" name="transmisi" value="<?php echo $data_cek['transmisi']; ?>"
					/>
				</div>
			</div>

			<div class="form-group row">
				<label class="col-sm-2 col-form-label">Tahun</label>
				<div class="col-sm-5">
					<input type="text" class="form-control" id="tahun" name="tahun" value="<?php echo $data_cek['tahun']; ?>"
					/>
				</div>
			</div>

			<div class="form-group row">
				<label class="col-sm-2 col-form-label">Status</label>
				<div class="col-sm-4">
					<select name="status" id="status" class="form-control">
						<option value="">-- Pilih --</option>
						<?php
                //cek data yg dipilih sebelumnya
                if ($data_cek['status'] == "Baru") echo "<option value='Baru' selected>Baru</option>";
                else echo "<option value='Baru'>Baru</option>";

                if ($data_cek['status'] == "Bekas") echo "<option value='Bekas' selected>Bekas</option>";
                else echo "<option value='Bekas'>Bekas</option>";
            			?>
					</select>
				</div>
			</div>

			<div class="form-group row">
				<label class="col-sm-2 col-form-label">Kilometer</label>
				<div class="col-sm-5">
					<input type="text" class="form-control" id="kilometer" name="kilometer" value="<?php echo $data_cek['kilometer']; ?>"
					/>
				</div>
			</div>

			<div class="form-group row">
				<label class="col-sm-2 col-form-label">Harga</label>
				<div class="col-sm-5">
					<input type="text" class="form-control" id="harga" name="harga" value="<?php echo $data_cek['harga']; ?>"
					/>
				</div>
			</div>

			<div class="form-group row">
				<label class="col-sm-2 col-form-label">Foto mobil</label>
				<div class="col-sm-6">
					<img src="foto/<?php echo $data_cek['foto']; ?>" width="160px" />
				</div>
			</div>

			<div class="form-group row">
				<label class="col-sm-2 col-form-label">Ubah Foto</label>
				<div class="col-sm-6">
					<input type="file" id="foto" name="foto">
					<p class="help-block">
						<font color="red">"Format file Jpg/Png"</font>
					</p>
				</div>
			</div>
		</div>

		<div class="card-footer">
			<input type="submit" name="Ubah" value="Simpan" class="btn btn-success">
			<a href="?page=data-mobil" title="Kembali" class="btn btn-secondary">Batal</a>
		</div>
	</form>
</div>

<?php
	$sumber = @$_FILES['foto']['tmp_name'];
	$target = 'foto/';
	$nama_file = @$_FILES['foto']['name'];
	$pindah = move_uploaded_file($sumber, $target.$nama_file);

	
if (isset ($_POST['Ubah'])){

    if(!empty($sumber)){
        $foto= $data_cek['foto'];
            if (file_exists("foto/$foto")){
            unlink("foto/$foto");}

        $sql_ubah = "UPDATE tb_mobil SET
			nama='".$_POST['nama']."',
			transmisi='".$_POST['transmisi']."',
			tahun='".$_POST['tahun']."',
			status='".$_POST['status']."',
			kilometer='".$_POST['kilometer']."',
			harga='".$_POST['harga']."',
			foto='".$nama_file."'		
            WHERE no_seri='".$_POST['no_seri']."'";
        $query_ubah = mysqli_query($koneksi, $sql_ubah);

    }elseif(empty($sumber)){
		$sql_ubah = "UPDATE tb_mobil SET
		nama='".$_POST['nama']."',
		transmisi='".$_POST['transmisi']."',
		tahun='".$_POST['tahun']."',
		status='".$_POST['status']."',
		kilometer='".$_POST['kilometer']."',
		harga='".$_POST['harga']."'		
		WHERE no_seri='".$_POST['no_seri']."'";
	$query_ubah = mysqli_query($koneksi, $sql_ubah);
        }

    if ($query_ubah) {
        echo "<script>
        Swal.fire({title: 'Ubah Data Berhasil',text: '',icon: 'success',confirmButtonText: 'OK'
        }).then((result) => {
            if (result.value) {
                window.location = 'index.php?page=data-mobil';
            }
        })</script>";
        }else{
        echo "<script>
        Swal.fire({title: 'Ubah Data Gagal',text: '',icon: 'error',confirmButtonText: 'OK'
        }).then((result) => {
            if (result.value) {
                window.location = 'index.php?page=data-mobil';
            }
        })</script>";
    }
}

